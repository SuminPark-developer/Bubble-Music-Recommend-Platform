<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Tracklist</title>
    <br>
    <center>
        <a href="./Rss_searchsong.html"><img id="bubble_logo" border="0"  src="./bubble_logo.png" alt = "버블로고" style="width:150px; height:50px;"></a> <!--이미지를 클릭하면 Rss_searchsong.html로 이동-->
    </center>
    <center><h1>Bubble Community</h1></center>
    <div align="right"><a href="./Rss_tracklist.html">My Bubble</a></div> <!--텍스트를 클릭하면 Rss_tracklist.html로 이동-->
    <div align="right"><a href="./Rss_main2.php">My page</a></div> <!--텍스트를 클릭하면 Rss_main2.php로 이동-->
    <div align="right"><a href="./Rss_MainPage.html">Log Out</a></div> <!--텍스트를 클릭하면 Rss_MainPage.html로 이동-->
    <style type="text/css">
        table {
            border: 0;
            border-collapse: collapse;
            border-spacing: 0;
        }

        table td, table th {
            border: 1px solid;
            padding: 2px 5px 2px 5px;
        }

        .text-center { text-align: center; }
        .text-right { text-align: right; }

        a {
            color:#000000;
            text-decoration:none;
        }

        a:hover {
            text-decoration:underline;
        }
    </style>
</head>

<body>
    <center>
        <a href="Rss_user_tracklist_bts.html"><img id="bts_logo" border="0"  src="./user_tracklist-BTS_logo.png"  style="width:200px; height:200px;" ></a>
        <a href="Rss_user_tracklist_rain.html"><img id="rain_logo.png" border="0"  src="./user_tracklist-rain_logo.png"  style="width:200px; height:200px;" ></a>
        <a href="Rss_user_tracklist_infinite_challenge.html"><img id="infinite_challenge_logo.png" border="0"  src="./user_tracklist-infinite_challenge_logo.png"  style="width:200px; height:200px;" ></a>
        <a href="Rss_user_tracklist_summer.html"><img id="summer_logo.png" border="0"  src="./user_tracklist-summer_logo.png"  style="width:200px; height:200px;" ></a>
        <!--이미지를 클릭하면 각각 링크된 페이지로 이동-->
    </center>
    <br><br><div align="center"><a href="./Rss_searchsong.html">노래 검색창으로 돌아가기</a></div> <!--텍스트를 클릭하면 Rss_searchsong.html로 이동-->
</body> 

</html>